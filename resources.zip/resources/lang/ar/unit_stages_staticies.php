<?php

return [
    'title' => 'إحصائيات الوحدات حسب المرحلة',
    'select_site' => 'اختر الموقع',
    'dhahran' => 'الظهران',
    'bashaer' => 'البشائر',
    'metric' => 'المؤشر',
    'price_range' => 'السعر (الأدنى - الأعلى)',
    'total_count' => 'إجمالي العدد',
    'available' => 'متاح',
    'contracted' => 'تم التعاقد',
    'reserved' => 'محجوز',
    'blocked' => 'محجوب',
    'contracted_percentage' => 'نسبة التعاقد',
    'sold_percentage' => 'نسبة المبيعات',
    'generated_at' => 'تم التوليد في',
    'export_pdf' => 'تصدير PDF',
];
