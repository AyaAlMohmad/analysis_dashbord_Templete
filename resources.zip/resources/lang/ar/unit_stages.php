<?php

return [
    'title' => 'تقرير حالة الوحدات',
    'select_site' => 'اختر الموقع',
    'dhahran' => 'الظهران',
    'bashaer' => 'البشائر',
    'phase' => 'المرحلة',
    'total_units' => 'إجمالي الوحدات',
    'reserved' => 'محجوز',
    'contacted' => 'تم التواصل',
    'available' => 'متاح',
    'blocked' => 'محجوب',
    'total' => 'الإجمالي',
    'generated_at' => 'تم توليد التقرير بتاريخ',
    
];
