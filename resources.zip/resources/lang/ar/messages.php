<?php
return[
    'color_map' => 'خريطة الملونة',
    'contracted_progress' => 'تقدم العقود',
    'disinterest_reasons' => 'أسباب عدم اهتمام',
    'monthly_appointments' => 'ازيارات الشهرية',
    'project_summary' => 'ملخص اجماليات المشروع',
    'reserved' => 'الحجوزات',
    'source_stats' => 'إحصائيات المصادر الحملات الإعلانية لشهر',
    'unit_cases'=>' حالات الوحدات',
    'targeted_month'=>' مستهدف شهر ',
    'total_sales'=>' إجمالي المبيعات البيعية',
    'unit_statistics_by_stage'=>'إحصائيات الوحدات حسب المرحلة',
    'unit_stages'=>'المرحلة حسب النموذج',
    'visits_payments_contracts'=>' الزيارات والسداد والعقود لشهر',
    'generating_report'=>'جاري تجهيز التقرير...',
];