<?php

return [
    'report_title' => 'تقرير الوحدات',
    'available' => 'متاحة',
    'reserved' => 'محجوزة',
    'blocked' => 'محجوبة',
    'contracted' => 'متعاقد عليها',
    'group' => 'المجموعة',
    'description' => 'الوصف',
    'status' => 'الحالة',
    'value' => 'العدد',
    'report_export_date' => 'تاريخ تصدير التقرير',
    'azyandhahran' => 'أزيان الظهران',
    'azyanbashaer' => 'أزيان البشائر',
];
