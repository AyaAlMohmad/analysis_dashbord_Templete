<?php

return [
    'title' => 'تقرير المصادر',
    'select_site' => '-- اختر الموقع --',
    'dhahran' => 'الظهران',
    'bashaer' => 'البشائر',
    'from_date' => 'من التاريخ:',
    'to_date' => 'إلى التاريخ:',
    'submit' => 'عرض التقرير',
    'source' => 'المصدر',
    'total_leads' => 'إجمالي العملاء المحتملين',
    'generated_at' => 'تم إنشاء التقرير في:',
    'export_pdf' => 'تصدير PDF',
    'cumulative' => 'تقرير تراكمي',
    'from_to' => 'من :from إلى :to',

];
