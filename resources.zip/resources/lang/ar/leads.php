<?php

return [
    'report_title' => 'تقرير العملاء',
    'select_location' => '📍 اختر الموقع',
    'choose_location' => '-- الرجاء اختيار موقع --',
    'site_dhahran' => 'أزيان الظهران',
    'site_bashaer' => 'أزيان البشائر',
    'daily_details' => 'تفاصيل العملاء اليومية',
    'date' => 'التاريخ',
    'added' => 'تمت الإضافة',
    'edited' => 'تم التعديل',
    'total' => 'الإجمالي',
    'show_details' => 'عرض التفاصيل',
    'hide_details' => 'إخفاء التفاصيل',
    'export_pdf' => 'تصدير PDF',
    'export_zip' => 'تصدير ZIP',
    'exported_by' => 'تم التصدير بواسطة',
    'export_date' => 'تاريخ التصدير',
    'view_log_dhahran' => 'سجل الظهران',
    'view_log_bashaer' => 'سجل البشائر',
    'status_overview' => 'نظرة عامة على الحالة',
    'status' => 'الحالة',
    'count' => 'الإجمالي',
    'dhahran' => 'أزيان الظهران',
    'bashaer' => 'أزيان البشائر',
    'report_title'=>'تقرير الحالة'
];
