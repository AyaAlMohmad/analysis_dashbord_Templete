<?php

return [
    'title' => 'Unit Statistics by Stage',
    'select_site' => 'Select Site',
    'dhahran' => 'Dhahran',
    'bashaer' => 'Bashaer',
    'metric' => 'Metric',
    'price_range' => 'Price (Min - Max)',
    'total_count' => 'Total Count',
    'available' => 'Available',
    'contracted' => 'Contracted',
    'reserved' => 'Reserved',
    'blocked' => 'Blocked',
    'contracted_percentage' => 'Contracted %',
    'sold_percentage' => 'Sold %',
    'generated_at' => 'Generated at',
    'export_pdf' => 'Export PDF',
];
