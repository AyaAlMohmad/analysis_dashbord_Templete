<?php

return [
    'edit_profile' => 'Edit Profile',
    'logout' => 'Logout',
    'arabic' => 'Arabic',
    'english' => 'English',
];
