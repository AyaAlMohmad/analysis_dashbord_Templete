<?php

return [
    'title' => 'Unit Stages Report',
    'select_site' => 'Select Site',
    'dhahran' => 'Dhahran',
    'bashaer' => 'Bashaer',
    'phase' => 'Phase',
    'total_units' => 'Total Units',
    'reserved' => 'Reserved',
    'contacted' => 'Contacted',
    'available' => 'Available',
    'blocked' => 'Blocked',
    'total' => 'Total',
    'generated_at' => 'Report generated at',
];
