<?php

return [
    'report_title' => 'Unit Report',
    'available' => 'Available',
    'reserved' => 'Reserved',
    'blocked' => 'Blocked',
    'contracted' => 'Contracted',
    'group' => 'Group',
    'description' => 'Description',
    'status' => 'Status',
    'value' => 'Count',
    'report_export_date' => 'Report Export Date',
    'azyandhahran' => 'Azyan Dhahran',
    'azyanbashaer' => 'Azyan Bashaer',
];
