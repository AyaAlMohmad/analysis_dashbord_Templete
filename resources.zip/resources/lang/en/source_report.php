<?php

return [
    'title' => 'Source Report',
    'select_site' => '-- Select Site --',
    'dhahran' => 'Dhahran',
    'bashaer' => 'Bashaer',
    'from_date' => 'From Date:',
    'to_date' => 'To Date:',
    'submit' => 'Generate Report',
    'cumulative' => 'Cumulative Report',
    'from_to' => 'From :from to :to',
    'source' => 'Source',
    'total_leads' => 'Total Leads',
    'generated_at' => 'Report generated at:',
    'export_pdf' => 'Export PDF',
];
