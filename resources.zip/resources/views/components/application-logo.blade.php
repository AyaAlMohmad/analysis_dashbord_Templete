<img src="{{asset('build/logo.png')}}" alt="Logo" class="mx-auto" style="max-width: 300px;">
{{-- 
 --}}