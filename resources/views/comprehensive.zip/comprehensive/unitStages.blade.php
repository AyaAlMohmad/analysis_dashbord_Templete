<div
style="background-color: #f9f6f2; padding: 60px 20px; font-family: 'Arial', sans-serif; direction: rtl; position: relative;">

<!-- Logo Top -->
<div style="position: absolute; top: 30px; right: 30px;">
    <img src="{{ asset('build/logo.png') }}" alt="Tatwir Logo" style="height: 50px;">
</div>

<!-- Title -->
<div style="text-align: center; margin-bottom: 40px;">
    <h2 style="font-size: 28px; color: #8b5a3b; border-bottom: 2px solid #8b5a3b; display: inline-block;">
        حالات الوحدات بالنماذج
    </h2>
</div>


<!-- Content Row -->
<div style="display: flex; flex-direction: row-reverse; align-items: flex-start;">
    <!-- Side Decoration -->
    <div style="flex: 0 0 auto; min-width: 100px; position: absolute; top: 100px;">
        <img src="{{ asset('images/style2.png') }}" alt="Decoration" style="height: 500px;">
    </div>

    <!-- Main Tables Container -->
    <div style="display: flex; flex-direction: column; gap: 30px; width: 100%; align-items: center;">

        <!-- First Table -->
        <table
            style="width: 90%; max-width: 800px; border-collapse: collapse; font-size: 12px; font-family: 'Arial', sans-serif; text-align: center; background-color: white; border: 1px solid #ccc;">
            <thead>
                <tr style="background-color: #fff; font-weight: bold; color: #333;">
                    <th style="border: 1px solid #ccc; width: 80px;">الأسعار</th>
                    <th style="border: 1px solid #ccc;">1,703,938</th>
                    <th style="border: 1px solid #ccc;">2,032,838</th>
                    <th style="border: 1px solid #ccc;">1,949,532</th>
                    <th style="border: 1px solid #ccc;">2,654,119</th>
                    <th style="border: 1px solid #ccc;">1,976,954</th>
                    <th style="border: 1px solid #ccc;">2,986,672</th>
                </tr>
                <tr style="background-color: #ffe082; font-weight: bold;">
                    <th style="border: 1px solid #ccc;">الإجمالي</th>
                    <th style="border: 1px solid #ccc;">A<br>عبق</th>
                    <th style="border: 1px solid #ccc;">B<br>إيوان</th>
                    <th style="border: 1px solid #ccc;">C<br>نجديه</th>
                    <th style="border: 1px solid #ccc;">D<br>رويق</th>
                    <th style="border: 1px solid #ccc;">E<br>مقام</th>
                    <th style="border: 1px solid #ccc;">F<br>روف</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="border: 1px solid #ccc; background-color: #ffe082;">النماذج</td>
                    <td style="border: 1px solid #ccc;">62</td>
                    <td style="border: 1px solid #ccc;">79</td>
                    <td style="border: 1px solid #ccc;">162</td>
                    <td style="border: 1px solid #ccc;">284</td>
                    <td style="border: 1px solid #ccc;">89</td>
                    <td style="border: 1px solid #ccc;">91</td>
                </tr>
                <tr>
                    <td style="border: 1px solid #ccc; background-color: #ffe082;">عدد الفلل</td>
                    <td style="border: 1px solid #ccc;">17</td>
                    <td style="border: 1px solid #ccc;">9</td>
                    <td style="border: 1px solid #ccc;">9</td>
                    <td style="border: 1px solid #ccc;">16</td>
                    <td style="border: 1px solid #ccc;">27</td>
                    <td style="border: 1px solid #ccc;">10</td>
                </tr>
                <tr>
                    <td style="border: 1px solid #ccc; background-color: #ffe082;">المحجوز</td>
                    <td style="border: 1px solid #ccc;">62</td>
                    <td style="border: 1px solid #ccc;">26</td>
                    <td style="border: 1px solid #ccc;">31</td>
                    <td style="border: 1px solid #ccc;">113</td>
                    <td style="border: 1px solid #ccc;">24</td>
                    <td style="border: 1px solid #ccc;">52</td>
                </tr>
                <tr>
                    <td style="border: 1px solid #ccc; background-color: #ffe082;">المنفذ</td>
                    <td style="border: 1px solid #ccc;">0</td>
                    <td style="border: 1px solid #ccc;">10</td>
                    <td style="border: 1px solid #ccc;">2</td>
                    <td style="border: 1px solid #ccc;">13</td>
                    <td style="border: 1px solid #ccc;">47</td>
                    <td style="border: 1px solid #ccc;">3</td>
                </tr>
                <tr>
                    <td style="border: 1px solid #ccc; background-color: #ffe082;">المحجوب</td>
                    <td style="border: 1px solid #ccc;">30</td>
                    <td style="border: 1px solid #ccc;">12</td>
                    <td style="border: 1px solid #ccc;">21</td>
                    <td style="border: 1px solid #ccc;">43</td>
                    <td style="border: 1px solid #ccc;">13</td>
                    <td style="border: 1px solid #ccc;">26</td>
                </tr>
                <tr style="background-color: #ffe082; font-weight: bold;">
                    <td style="border: 1px solid #ccc;">الإجمالي</td>
                    <td style="border: 1px solid #ccc;">62</td>
                    <td style="border: 1px solid #ccc;">79</td>
                    <td style="border: 1px solid #ccc;">162</td>
                    <td style="border: 1px solid #ccc;">284</td>
                    <td style="border: 1px solid #ccc;">89</td>
                    <td style="border: 1px solid #ccc;">91</td>
                </tr>
                <tr style="background-color: #8b5a3b; color: white; font-weight: bold;">
                    <td style="border: 1px solid #ccc;">المنفذ النهائي</td>
                    <td style="border: 1px solid #ccc;">48%</td>
                    <td style="border: 1px solid #ccc;">32%</td>
                    <td style="border: 1px solid #ccc;">46%</td>
                    <td style="border: 1px solid #ccc;">51%</td>
                    <td style="border: 1px solid #ccc;">67%</td>
                    <td style="border: 1px solid #ccc;">32%</td>
                </tr>
                <tr style="background-color: #8b5a3b; color: white; font-weight: bold;">
                    <td style="border: 1px solid #ccc;">نسبة النموذج من المجموع</td>
                    <td style="border: 1px solid #ccc;">52%</td>
                    <td style="border: 1px solid #ccc;">52%</td>
                    <td style="border: 1px solid #ccc;">54%</td>
                    <td style="border: 1px solid #ccc;">49%</td>
                    <td style="border: 1px solid #ccc;">33%</td>
                    <td style="border: 1px solid #ccc;">68%</td>
                </tr>
            </tbody>
        </table>

        <!-- Second Table -->
        <table
            style="width: 50%; direction: rtl; border-collapse: collapse; font-size: 13px; font-family: 'Arial'; text-align: center; border: 1px solid #ccc;">
            <tr style="background-color: #5e3d2c; color: white; font-weight: bold;">
                <td style="border: 1px solid #ccc; text-align: right;">إجمالي المبيع والمحجوز 396 (عبق - إيوان)
                </td>
                <td style="border: 1px solid #ccc; background-color: #ffe082; color: black;">19.4%</td>
                <td style="border: 1px solid #ccc;">النسب من المبيع</td>
                <td style="border: 1px solid #ccc; background-color: #ffe082; color: black;">77</td>
            </tr>
            <tr style="background-color: #5e3d2c; color: white; font-weight: bold;">
                <td style="border: 1px solid #ccc; text-align: right;">إجمالي المبيع والمحجوز 396 (نجديه - رويق)
                </td>
                <td style="border: 1px solid #ccc; background-color: #ffe082; color: black;">57.6%</td>
                <td style="border: 1px solid #ccc;">النسب من المبيع</td>
                <td style="border: 1px solid #ccc; background-color: #ffe082; color: black;">228</td>
            </tr>
            <tr style="background-color: #5e3d2c; color: white; font-weight: bold;">
                <td style="border: 1px solid #ccc; text-align: right;">إجمالي المبيع والمحجوز 396 (مقام - روف)</td>
                <td style="border: 1px solid #ccc; background-color: #ffe082; color: black;">23.0%</td>
                <td style="border: 1px solid #ccc;">النسب من المبيع</td>
                <td style="border: 1px solid #ccc; background-color: #ffe082; color: black;">91</td>
            </tr>
        </table>

    </div>
</div>


<!-- Logo Bottom -->
<div style="position: absolute; right: 30px; bottom: 30px;">
    <img src="{{ asset('images/logo1.png') }}" alt="Azyan Logo" style="height: 70px;">
</div>

</div>