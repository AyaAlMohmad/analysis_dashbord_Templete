<div
style="background-color: #f9f6f2; padding: 60px 20px; font-family: 'Arial', sans-serif; direction: rtl; position: relative;">

<!-- Logo Top -->
<div style="position: absolute; top: 30px; right: 30px;">
    <img src="{{ asset('build/logo.png') }}" alt="Tatwir Logo" style="height: 50px;">
</div>

<!-- Title -->
<div style="text-align: center; margin-bottom: 40px;">
    <h2 style="font-size: 28px; color: #8b5a3b; border-bottom: 2px solid #8b5a3b; display: inline-block;">
        حالات الوحدات بالنماذج
    </h2>
</div>

<!-- Content Row -->
<!-- Content Row -->
<div style="display: flex; flex-direction: row-reverse; align-items: flex-start;">
    <!-- Side Decoration -->
    <div style="flex: 0 0 auto; min-width: 100px; position: absolute; top: 100px;">
        <img src="{{ asset('images/style2.png') }}" alt="Decoration" style="height: 500px;">
    </div>

    <!-- Main Tables Container -->
    <div
        style="flex: 1 0 auto; display: grid;margin-right: 120px;margin-left: 120px; grid-template-columns: repeat(2, 1fr); gap: 12px; font-family: 'Arial', sans-serif; font-size: 9px;">
        @for ($i = 1; $i <= 4; $i++)
            <table
                style="border-collapse: collapse; background-color: white; table-layout: fixed; font-size: 8px; width: 100%; max-width: 400px;">
                <caption style="font-weight: bold; margin-bottom: 3px;">مرحلة رقم {{ $i }}</caption>
                <thead style="background-color: #ffe082; font-weight: bold;">
                    <tr>
                        <th style="border: 1px solid #ccc; padding: 2px; font-size: 8px;">النموذج</th>
                        <th style="border: 1px solid #ccc; padding: 2px;">الوحدات</th>
                        <th style="border: 1px solid #ccc; padding: 2px;">المبيع/متاح</th>
                        <th style="border: 1px solid #ccc; padding: 2px;">من</th>
                        <th style="border: 1px solid #ccc; padding: 2px;">إلى</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach (['عبق A', 'إيوان B', 'نجديه C', 'رويق D', 'مقام E', 'روف F'] as $model)
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 2px;">{{ $model }}</td>
                            <td style="border: 1px solid #ccc; padding: 2px;">--</td>
                            <td style="border: 1px solid #ccc; padding: 2px;">--</td>
                            <td style="border: 1px solid #ccc; padding: 2px;">--</td>
                            <td style="border: 1px solid #ccc; padding: 2px;">--</td>
                        </tr>
                    @endforeach
                    <tr style="background-color: #eee; font-weight: bold;">
                        <td style="border: 1px solid #ccc; padding: 2px;">إجمالي المرحلة</td>
                        <td style="border: 1px solid #ccc; padding: 2px;">--</td>
                        <td style="border: 1px solid #ccc; padding: 2px;">--</td>
                        <td style="border: 1px solid #ccc; padding: 2px;" colspan="2">---</td>
                    </tr>
                </tbody>
            </table>
        @endfor
    </div>

</div>


<!-- Logo Bottom -->
<div style="position: absolute; right: 30px; bottom: 30px;">
    <img src="{{ asset('images/logo1.png') }}" alt="Azyan Logo" style="height: 50px;">
</div>

</div>
<div
style="background-color: #f9f6f2; padding: 60px 20px; font-family: 'Arial', sans-serif; direction: rtl; position: relative;">

<!-- Logo Top -->
<div style="position: absolute; top: 30px; right: 30px;">
    <img src="{{ asset('build/logo.png') }}" alt="Tatwir Logo" style="height: 50px;">
</div>

<!-- Title -->
<div style="text-align: center; margin-bottom: 40px;">
    <h2 style="font-size: 28px; color: #8b5a3b; border-bottom: 2px solid #8b5a3b; display: inline-block;">
        حالات الوحدات بالنماذج
    </h2>
</div>

<!-- Content Row -->
<div style="display: flex; flex-direction: row-reverse; align-items: flex-start;">
    <!-- Side Decoration -->
    <div style="flex: 0 0 auto; min-width: 100px; position: absolute; top: 100px;">
        <img src="{{ asset('images/style2.png') }}" alt="Decoration" style="height: 500px;">
    </div>

    <!-- Main Tables Container -->
    <div
        style="flex: 1 0 auto; display: grid;margin-right: 120px;margin-left: 120px; grid-template-columns: repeat(2, 1fr); gap: 12px; font-family: 'Arial', sans-serif; font-size: 9px;">
        @for ($i = 1; $i <= 4; $i++)
            <table
                style="border-collapse: collapse; background-color: white; table-layout: fixed; font-size: 8px; width: 100%; max-width: 400px;">
                <caption style="font-weight: bold; margin-bottom: 3px;">مرحلة رقم {{ $i }}</caption>
                <thead style="background-color: #ffe082; font-weight: bold;">
                    <tr>
                        <th style="border: 1px solid #ccc; padding: 2px; font-size: 8px;">النموذج</th>
                        <th style="border: 1px solid #ccc; padding: 2px;">الوحدات</th>
                        <th style="border: 1px solid #ccc; padding: 2px;">المبيع/متاح</th>
                        <th style="border: 1px solid #ccc; padding: 2px;">من</th>
                        <th style="border: 1px solid #ccc; padding: 2px;">إلى</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach (['عبق A', 'إيوان B', 'نجديه C', 'رويق D', 'مقام E', 'روف F'] as $model)
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 2px;">{{ $model }}</td>
                            <td style="border: 1px solid #ccc; padding: 2px;">--</td>
                            <td style="border: 1px solid #ccc; padding: 2px;">--</td>
                            <td style="border: 1px solid #ccc; padding: 2px;">--</td>
                            <td style="border: 1px solid #ccc; padding: 2px;">--</td>
                        </tr>
                    @endforeach
                    <tr style="background-color: #eee; font-weight: bold;">
                        <td style="border: 1px solid #ccc; padding: 2px;">إجمالي المرحلة</td>
                        <td style="border: 1px solid #ccc; padding: 2px;">--</td>
                        <td style="border: 1px solid #ccc; padding: 2px;">--</td>
                        <td style="border: 1px solid #ccc; padding: 2px;" colspan="2">---</td>
                    </tr>
                </tbody>
            </table>
        @endfor
    </div>

</div>


<!-- Logo Bottom -->
<div style="position: absolute; right: 30px; bottom: 30px;">
    <img src="{{ asset('images/logo1.png') }}" alt="Azyan Logo" style="height: 50px;">
</div>

</div>