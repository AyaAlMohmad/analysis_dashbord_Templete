<?php
return[
    'color_map' => 'Color Map',
    'contracted_progress' => 'Contracted progress',
    'disinterest_reasons' => 'Disinterest reasons',
    'monthly_appointments' => 'Monthly Appointments',
    'project_summary' => 'Project Summary',
    'reserved' => 'Reserved',
    'source_stats' => 'Statistics Sources Advertising Campaigns for the Month',
    'unit_cases'=>'Unit cases',
    'targeted_month'=>'Target for the month',
    'total_sales'=>'Total sales',
    'unit_statistics_by_stage'=>'Unit Statistics by Stage',
    'unit_stages'=>'Unit Stages',
    'visits_payments_contracts'=>'Visits & Payments & Contracts For The Month',
];