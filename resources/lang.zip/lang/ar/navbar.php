<?php

return [
    'edit_profile' => 'تعديل الملف الشخصي',
    'logout' => 'تسجيل الخروج',
    'arabic' => 'العربية',
    'english' => 'الإنجليزية',
];
